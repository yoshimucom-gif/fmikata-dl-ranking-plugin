<?php
/**
 * 設定の既定値と読み書き。
 *
 * カテゴリのスラッグと Flamingo のフィールド名は、サイト側の都合で変わりうる。
 * ここをハードコードせず設定に逃がしてあるのは、記事のカテゴリ構成を作り直したときに
 * プラグインを触らずに追随できるようにするため。
 */

if (!defined('ABSPATH')) exit;

class FDR_Settings {

    /**
     * 設定の世代。既定値を変えても、DBに保存済みの設定のほうが優先される。
     * 「既定を直したのに画面が変わらない」を防ぐため、変えたい項目はここで一度だけ上書きする。
     */
    const DBVER = 2;

    /** 既定値。install() と get() の両方から参照する */
    public static function defaults() {
        return array(
            // ── 集計対象のカテゴリ（親スラッグ）
            'service_slug'   => 'service',
            'knowhow_slug'   => 'knowhow',

            // ── Flamingo の受信データ側のフィールド名（CF7 のフィールド名に対応）
            'field_title'    => '_field_service',
            'field_url'      => '_field_URL',
            'field_email'    => '_field_your-email',
            'field_price'    => '_field_price',

            // ── 集計の既定
            'candidates'     => 15,   // 候補として出す件数
            'picks'          => 10,   // 掲載する件数
            'unique_email'   => 0,    // 1 なら同一メールアドレスの重複を除いて数える
            'service_range'  => 'prev1m', // ①の既定期間
            'knowhow_range'  => 'prev1m', // ②の既定期間

            // ── TOPへの反映
            'top_post_id'     => 0,   // ランキング枠を置いている記事（TOPは firstview のことが多い）
            'top_month_label' => 1,   // 見出しの「2026年7月」を一緒に書き換えるか

            // ── 除外
            'exclude_urls'   => "https://store.f-mikata.jp/cv/",
            'exclude_emails' => '',

            // ── 出力
            'mail_intro'     =>"いつもご利用いただきありがとうございます。\n本メールでは、直近1ヶ月でよくダウンロードされた資料をランキング形式でご紹介いたします。\n\nまだご覧になっていない方は、ぜひこの機会にダウンロードしてください！\n\n‼資料は予告なく掲載停止する可能性がございます。あらかじめご了承ください。",
            'mail_outro'     => "是非、集客や営業活動にお役立てください。\n最後までご覧いただきありがとうございました。\n今後ともよろしくお願いいたします。",
            'heading_service' => '不動産会社向けサービス 人気ランキング',
            'heading_knowhow' => '不動産会社向けノウハウ資料 人気ランキング',

            // 一覧（名前とURLだけ。そのまま貼れる形）
            'item_tpl_list'  => "{n}．{title}（{url}）",
            // メール本文（一言コメント入り）
            'item_tpl_text'  => "{no}{title}\n≪{comment}≫\n{url}\n",
        );
    }

    /** 設定を1件取得 */
    public static function get($key = null) {
        $opt = get_option(FDR_OPT, array());
        if (!is_array($opt)) $opt = array();
        $opt = array_merge(self::defaults(), $opt);
        if ($key === null) return $opt;
        return isset($opt[$key]) ? $opt[$key] : null;
    }

    /** 設定を保存（既定値にないキーは捨てる） */
    public static function save($input) {
        $defaults = self::defaults();
        $clean = self::get();

        foreach ($defaults as $key => $default) {
            if (!isset($input[$key])) continue;
            $val = $input[$key];

            switch ($key) {
                case 'candidates':
                case 'picks':
                    $val = max(1, min(30, (int)$val));
                    break;
                case 'unique_email':
                case 'top_month_label':
                    $val = $val ? 1 : 0;
                    break;
                case 'top_post_id':
                    $val = max(0, (int)$val);
                    break;
                case 'service_range':
                case 'knowhow_range':
                    $val = array_key_exists($val, FDR_Aggregator::ranges()) ? $val : $default;
                    break;
                case 'mail_intro':
                case 'mail_outro':
                case 'item_tpl_list':
                case 'item_tpl_text':
                case 'exclude_urls':
                case 'exclude_emails':
                    $val = sanitize_textarea_field(wp_unslash($val));
                    break;
                default:
                    $val = sanitize_text_field(wp_unslash($val));
            }
            $clean[$key] = $val;
        }

        // 掲載件数が候補件数を超えないようにそろえる
        if ($clean['picks'] > $clean['candidates']) {
            $clean['candidates'] = $clean['picks'];
        }

        update_option(FDR_OPT, $clean, false);
        delete_transient(FDR_MAP_CACHE);
        return $clean;
    }

    /** 有効化時。既存の設定があれば触らない */
    public static function install() {
        $opt = get_option(FDR_OPT, null);
        if (!is_array($opt)) {
            add_option(FDR_OPT, self::defaults(), '', false);
        }
        self::maybe_upgrade();
    }

    /**
     * 版が上がったときに一度だけ走る移行。
     *
     * v1.0.0 は①の既定が「直近3ヶ月」だった。その値がDBに残っていると、
     * 既定を先月に変えても画面は3ヶ月のままになる。ここで一度だけ捨てる。
     */
    public static function maybe_upgrade() {
        $from = (int)get_option(FDR_DBVER_OPT, 0);
        if ($from >= self::DBVER) return;

        $opt = get_option(FDR_OPT, null);
        if (is_array($opt)) {
            if ($from < 2) {
                $opt['service_range'] = 'prev1m';
                // 使わなくなった設定を残しておく理由がない
                unset($opt['accent_color'], $opt['item_tpl_html']);
            }
            update_option(FDR_OPT, $opt, false);
        }

        update_option(FDR_DBVER_OPT, self::DBVER, false);
        delete_transient(FDR_MAP_CACHE);
    }

    /** 改行区切りの設定値を配列にする */
    public static function lines($key) {
        $raw = (string)self::get($key);
        $out = array();
        foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
            $line = trim($line);
            if ($line !== '') $out[] = $line;
        }
        return $out;
    }
}
